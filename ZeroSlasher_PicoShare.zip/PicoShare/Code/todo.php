check if a url already exists when is given to short, if exists return that tocken.

validation for user prfile page, entire page

validation for alias in home page
